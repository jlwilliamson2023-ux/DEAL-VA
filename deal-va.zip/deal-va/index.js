const express = require('express');
const bodyParser = require('body-parser');
const Anthropic = require('@anthropic-ai/sdk');
const sqlite3 = require('sqlite3').verbose();
const nodemailer = require('nodemailer');
const twilio = require('twilio');
require('dotenv').config();

const app = express();
app.use(bodyParser.json());

// Initialize clients
const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY
});

const db = new sqlite3.Database('./deals.db');

// Twilio SMS
const twilioClient = process.env.TWILIO_ACCOUNT_SID ? 
  twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN) : null;

// Email
const emailTransporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

// Database setup
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS deals (
    id INTEGER PRIMARY KEY,
    address TEXT,
    property_type TEXT,
    price REAL,
    market TEXT,
    business_type TEXT,
    source TEXT,
    deal_data TEXT,
    evaluation TEXT,
    status TEXT DEFAULT 'new',
    metrics TEXT,
    fee_potential REAL,
    exceptional BOOLEAN,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    notified_at DATETIME
  )`);
});

// Kill rubrics for each business
const killRubrics = {
  wmd: {
    minPrice: 10000000,
    maxPrice: 150000000,
    minUnits: 32,
    minNOI: 900000,
    minOccupancy: 80,
    classes: ['A', 'B'],
    capRateMin: 3,
    capRateMax: 8
  },
  ryan_stlouis: {
    units: [2, 3, 4],
    minArv: 100000,
    purchasePerUnit: 100000,
    arvSpreadMin: 20000
  },
  david_ross: {
    units: [1, 2, 3, 4, 5],
    minPrice: 100000,
    maxPrice: 550000,
    qualifies: true // Waiting on David's criteria
  },
  bp_rvpark: {
    minPads: 20,
    maxPrice: 2000000,
    minCashflow: 12000,
    sellerFinancePreferred: true
  }
};

// Deal evaluation using Claude
async function evaluateDeal(dealData, businessType) {
  const prompt = `
You are a real estate deal evaluator for ${businessType}.

Deal Data:
${JSON.stringify(dealData, null, 2)}

Evaluate this deal based on these criteria for ${businessType}:
${JSON.stringify(killRubrics[businessType], null, 2)}

Respond ONLY with JSON (no markdown, no extra text):
{
  "passes_kill_rubric": boolean,
  "rejection_reason": "string or null",
  "metrics": {
    "cap_rate": number or null,
    "arv_spread": number or null,
    "cashflow": number or null,
    "fee_potential": number or null
  },
  "quality_score": number (0-100),
  "summary": "brief summary of deal quality",
  "exceptional": boolean,
  "next_steps": "array of recommended actions"
}
`;

  try {
    const message = await anthropic.messages.create({
      model: "claude-opus-4-20250805",
      max_tokens: 500,
      messages: [{ role: "user", content: prompt }]
    });

    const responseText = message.content[0].text;
    return JSON.parse(responseText);
  } catch (error) {
    console.error('Claude evaluation error:', error);
    return { passes_kill_rubric: false, rejection_reason: 'Evaluation failed' };
  }
}

// Send SMS notification
async function sendSMS(message, exceptional = false) {
  if (!twilioClient) {
    console.log('SMS disabled (no Twilio config)');
    return;
  }

  try {
    await twilioClient.messages.create({
      body: message,
      from: process.env.TWILIO_PHONE,
      to: process.env.OWNER_PHONE
    });
    console.log('SMS sent:', message);
  } catch (error) {
    console.error('SMS error:', error);
  }
}

// Send email notification
async function sendEmail(subject, htmlContent, exceptional = false) {
  try {
    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: process.env.OWNER_EMAIL,
      subject: exceptional ? `🔥 EXCEPTIONAL DEAL: ${subject}` : subject,
      html: htmlContent
    };

    await emailTransporter.sendMail(mailOptions);
    console.log('Email sent:', subject);
  } catch (error) {
    console.error('Email error:', error);
  }
}

// Process incoming deal
async function processDeal(dealData, source) {
  const businessType = dealData.business_type || 'wmd';
  
  console.log(`\n🔍 Processing deal from ${source}:`, dealData);

  // Evaluate deal
  const evaluation = await evaluateDeal(dealData, businessType);

  if (!evaluation.passes_kill_rubric) {
    console.log(`❌ Deal rejected: ${evaluation.rejection_reason}`);
    return { status: 'rejected', reason: evaluation.rejection_reason };
  }

  // Store in database
  const insertQuery = `
    INSERT INTO deals (address, property_type, price, market, business_type, source, deal_data, evaluation, status, metrics, fee_potential, exceptional)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;

  db.run(insertQuery, [
    dealData.address,
    dealData.property_type,
    dealData.price,
    dealData.market || 'unknown',
    businessType,
    source,
    JSON.stringify(dealData),
    JSON.stringify(evaluation),
    'qualified',
    JSON.stringify(evaluation.metrics),
    evaluation.metrics.fee_potential || 0,
    evaluation.exceptional ? 1 : 0
  ], function(err) {
    if (err) console.error('Database insert error:', err);
    else console.log(`✅ Deal stored with ID: ${this.lastID}`);
  });

  // Build notification
  const summary = `
${businessType.toUpperCase()} DEAL FOUND
Address: ${dealData.address}
Price: $${(dealData.price || 0).toLocaleString()}
Market: ${dealData.market || 'N/A'}
Quality Score: ${evaluation.quality_score}/100
Fee Potential: $${(evaluation.metrics.fee_potential || 0).toLocaleString()}

${evaluation.summary}
  `.trim();

  // Send notifications
  const smsMsg = `✅ ${businessType}: ${dealData.address} - Quality: ${evaluation.quality_score}/100 - Fee: $${(evaluation.metrics.fee_potential || 0).toLocaleString()}`;
  
  await sendSMS(smsMsg, evaluation.exceptional);
  await sendEmail(
    `${businessType}: ${dealData.address}`,
    `<pre>${summary}</pre><p><strong>Full Evaluation:</strong></p><pre>${JSON.stringify(evaluation, null, 2)}</pre>`,
    evaluation.exceptional
  );

  return { status: 'qualified', evaluation };
}

// API endpoint: Receive deal from Zapier/Forms
app.post('/api/deal', async (req, res) => {
  const deal = req.body;
  const source = req.headers['x-source'] || 'api';
  
  const result = await processDeal(deal, source);
  res.json(result);
});

// API endpoint: Get all deals
app.get('/api/deals', (req, res) => {
  db.all(`
    SELECT * FROM deals 
    ORDER BY created_at DESC 
    LIMIT 50
  `, (err, rows) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.json(rows);
    }
  });
});

// API endpoint: Get deals by market
app.get('/api/deals/:market', (req, res) => {
  db.all(`
    SELECT * FROM deals 
    WHERE business_type = ? 
    ORDER BY created_at DESC 
    LIMIT 20
  `, [req.params.market], (err, rows) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.json(rows);
    }
  });
});

// Scheduled tasks (run daily digest)
async function sendDailyDigest() {
  db.all(`
    SELECT * FROM deals 
    WHERE DATE(created_at) = DATE('now') 
    AND status = 'qualified'
    ORDER BY fee_potential DESC
  `, async (err, deals) => {
    if (err) {
      console.error('Digest query error:', err);
      return;
    }

    if (deals.length === 0) {
      console.log('No deals today');
      return;
    }

    const digestHtml = `
      <h2>Daily Deal Digest - ${new Date().toLocaleDateString()}</h2>
      <p>Found ${deals.length} qualified deals today:</p>
      <table border="1" cellpadding="10">
        <tr>
          <th>Address</th>
          <th>Business</th>
          <th>Price</th>
          <th>Fee Potential</th>
          <th>Quality</th>
        </tr>
        ${deals.map(d => `
          <tr>
            <td>${d.address}</td>
            <td>${d.business_type}</td>
            <td>$${(d.price || 0).toLocaleString()}</td>
            <td>$${(d.fee_potential || 0).toLocaleString()}</td>
            <td>${JSON.parse(d.evaluation || '{}').quality_score || 'N/A'}/100</td>
          </tr>
        `).join('')}
      </table>
    `;

    await sendEmail('Daily Deal Digest', digestHtml);
  });
}

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🤖 Deal VA running on port ${PORT}`);
  console.log('Listening for incoming deals...');
});

// Close database on exit
process.on('SIGINT', () => {
  db.close();
  process.exit(0);
});
