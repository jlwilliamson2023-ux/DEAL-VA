# QUICK START - LANDON'S DEAL VA

**Get your autonomous deal sourcing running in 30 minutes.**

---

## 3 QUICK STEPS

### Step 1: Get API Keys (10 min)

1. **Anthropic** → https://console.anthropic.com/ → Create API key
2. **Gmail** → https://myaccount.google.com/security → App password
3. **Twilio** → https://www.twilio.com/console/ → Account SID, Auth Token, Phone

Copy these into `.env` file (use `.env.example` as template)

### Step 2: Deploy Server (10 min)

1. Go to https://render.com
2. Sign up → New Web Service
3. Upload `deal-va` folder
4. Add environment variables
5. Click Deploy

You get a live URL like: `https://landon-deal-va.onrender.com`

### Step 3: Connect Deal Sources (10 min)

Go to https://zapier.com and create Zaps that send deals to:

```
POST https://your-server.onrender.com/api/deal
```

Connect:
- CreXi Listings
- LoopNet Listings  
- Your MLS
- Google Forms submissions
- Anything else that sends deals

---

## TEST IT

```bash
curl -X POST https://your-server.onrender.com/api/deal \
  -H "Content-Type: application/json" \
  -d '{
    "address": "100 Main St",
    "price": 15000000,
    "business_type": "wmd",
    "units": 50,
    "noi": 1200000,
    "cap_rate": 6.2
  }'
```

You should get:
- ✅ SMS notification
- ✅ Email with full evaluation
- ✅ Deal stored in database

---

## DONE!

Your VA is now running 24/7. 

Every deal that comes in gets:
- Auto-evaluated by Claude AI
- Checked against your buybox
- Ranked by quality
- Sent to you via SMS + email

Check `/api/deals` anytime to see all deals found.

---

## WHAT HAPPENS NEXT

1. **Deal comes in** → Any source (Zapier, form, email)
2. **VA evaluates** → Claude AI checks against your criteria
3. **You get notified** → SMS + email with analysis
4. **Deal stored** → Searchable database forever
5. **Daily digest** → Top deals each morning

---

For detailed setup, see: DEPLOYMENT.md

For code details, see: index.js

