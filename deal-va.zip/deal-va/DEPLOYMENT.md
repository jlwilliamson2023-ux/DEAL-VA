# LANDON'S AUTONOMOUS DEAL VA - DEPLOYMENT GUIDE

Your 24/7 deal sourcing AI agent is ready to deploy. Follow these steps to get it running.

---

## WHAT THIS SYSTEM DOES

✅ Monitors deals from ALL sources 24/7
✅ Auto-evaluates deals using Claude AI
✅ Sends SMS + Email notifications immediately
✅ Sends daily digest with all qualified deals
✅ Stores all deals in a searchable database
✅ Evaluates against YOUR specific buybox criteria
✅ Calculates fee potential automatically

---

## STEP 1: GET YOUR API KEYS

### 1A. Anthropic API Key (REQUIRED - for deal evaluation)
- Go to https://console.anthropic.com/
- Create account or log in
- Create new API key
- Copy key → save to .env file

### 1B. Gmail (REQUIRED - for email notifications)
- Go to https://myaccount.google.com/
- Security → 2-Step Verification (enable if needed)
- App Passwords → Generate for "Mail"
- Copy password → save to .env

### 1C. Twilio (REQUIRED - for SMS alerts)
- Go to https://www.twilio.com/console/
- Create free account (gets $15 credit)
- Get your Account SID and Auth Token
- Get a phone number (free trial number works)
- Copy all → save to .env

---

## STEP 2: SET UP ENVIRONMENT

1. Open `.env.example`
2. Fill in ALL fields with your actual credentials
3. Rename to `.env`

Example:
```
ANTHROPIC_API_KEY=sk-ant-v0-abc123...
EMAIL_USER=your_email@gmail.com
EMAIL_PASS=abcd efgh ijkl mnop
TWILIO_ACCOUNT_SID=ACxxxxxx
TWILIO_AUTH_TOKEN=your_token_here
TWILIO_PHONE=+14155552671
OWNER_EMAIL=your_email@gmail.com
OWNER_PHONE=+12025551234
```

---

## STEP 3: DEPLOY TO FREE SERVER (5 MINUTES)

### Option A: Render.com (Recommended - easiest)

1. Go to https://render.com
2. Sign up with GitHub or email
3. Click "New +" → "Web Service"
4. Connect this GitHub repo (or upload zip)
5. Name: `landon-deal-va`
6. Runtime: Node
7. Build: `npm install`
8. Start: `npm start`
9. Add environment variables from .env
10. Deploy! 🚀

Your server lives at: `https://landon-deal-va.onrender.com`

### Option B: Railway.app (Also free)

1. Go to https://railway.app
2. Connect GitHub repo
3. Add environment variables
4. Deploy
5. Get URL

### Option C: Local Computer (For testing)

```bash
npm install
node index.js
```

Runs on http://localhost:3000

---

## STEP 4: SET UP DEAL SOURCES

### Source 1: Zapier (Automates CreXi/LoopNet/MLS)

1. Go to https://zapier.com
2. Create Zap: "CreXi New Listing" → "Webhook"
3. Webhook URL: `https://your-server.onrender.com/api/deal`
4. Format data as JSON:
```json
{
  "address": "123 Main St",
  "property_type": "multifamily",
  "price": 15000000,
  "market": "Texas",
  "business_type": "wmd",
  "units": 45,
  "noi": 1200000,
  "occupancy": 85,
  "cap_rate": 6.5
}
```

Repeat for:
- LoopNet New Listings
- MLS Listings (in your markets)
- Any other source that supports webhooks

### Source 2: Email Forwarding

1. Set up forwarding: broker_emails@yourdomain.com → your server
2. Server parses emails and extracts deal info
3. Auto-sends to evaluation

### Source 3: Google Forms

Create form for brokers/wholesalers with fields:
- Property Address
- Price
- Units
- Property Type
- Business Type

Connect form to Zapier → send to your server

### Source 4: Slack Integration

Post deals in #deals channel → bot evaluates automatically

---

## STEP 5: TEST THE SYSTEM

Send a test deal:

```bash
curl -X POST http://localhost:3000/api/deal \
  -H "Content-Type: application/json" \
  -H "X-Source: test" \
  -d '{
    "address": "456 Oak Ave, St. Louis, MO",
    "property_type": "multifamily",
    "price": 500000,
    "market": "St. Louis",
    "business_type": "ryan_stlouis",
    "units": 4,
    "condition": "needs_rehab"
  }'
```

You should receive:
- SMS notification
- Email with evaluation
- Deal stored in database

---

## STEP 6: VIEW ALL DEALS

Open browser:
```
https://your-server.onrender.com/api/deals
```

See all deals found by the VA.

Filter by market:
```
https://your-server.onrender.com/api/deals/wmd
https://your-server.onrender.com/api/deals/ryan_stlouis
https://your-server.onrender.com/api/deals/bp_rvpark
```

---

## KILL RUBRICS (Auto-Applied by VA)

### WMD
- Price: $10M - $150M
- Units: 32+
- NOI: >$900K
- Occupancy: >80%
- Cap Rate: 5-7% for SMS alert (otherwise email)
- Class: A or B

### Ryan (St. Louis)
- Units: 2-4
- ARV Spread: >$20K
- All qualified deals get SMS

### David (NC)
- Units: 1-5
- Price: $100K-$550K
- All qualified deals get SMS

### BP (RV Parks)
- Pads: 20+
- Price: <$2M
- Cashflow potential: >$12K/month
- All qualified deals get SMS

---

## MANAGING THE VA

### Daily Digest Email
Automatically sent each morning at 8am with:
- All deals found yesterday
- Ranked by fee potential
- Quality scores
- Summaries

### Real-Time Alerts
Get SMS immediately when:
- WMD deal with 5-7% cap rate found
- Any Ryan deal found
- Any David Ross deal found
- Any BP RV park found

### Database
All deals stored forever. Search anytime:
- By market
- By date
- By quality score
- By fee potential

---

## TROUBLESHOOTING

**No SMS received?**
- Check Twilio credits (need at least $0.01)
- Verify phone number in .env
- Check logs in Render/Railway dashboard

**No email received?**
- Check Gmail app password (not regular password)
- Allow less secure apps if needed
- Check spam folder

**Deals not being processed?**
- Check that Zapier webhook URL is correct
- Test with curl command above
- Check server logs

**Need to update buybox?**
- Edit `killRubrics` in index.js
- Redeploy

---

## ONGOING OPERATION

Once deployed:
1. Deals flow in automatically 24/7
2. VA evaluates each deal
3. You get SMS + email notifications
4. Check daily digest each morning
5. Follow up on deals that look good

That's it. The VA handles everything else. ✅

---

## FUTURE ENHANCEMENTS

- Auto-send to partners (Ryan, David, WMD)
- Auto-populate your spreadsheets
- Advanced filtering by multiple criteria
- Deal analytics dashboard
- Competitor pricing alerts
- Market trend analysis

---

## SUPPORT

If anything breaks:
1. Check server logs (Render/Railway dashboard)
2. Verify environment variables
3. Test with curl command
4. Check that all APIs are connected

Good luck! 🚀

