# LANDON'S AUTONOMOUS DEAL SOURCING VA

A fully autonomous 24/7 real estate deal sourcing system powered by Claude AI.

**What it does:**
- Monitors multiple deal sources simultaneously
- Auto-evaluates deals against your specific criteria
- Sends SMS + Email alerts when deals are found
- Stores all deals in a searchable database
- Calculates fee potential automatically
- Runs completely hands-off

---

## FILES IN THIS FOLDER

1. **index.js** - Main application code (the VA engine)
2. **package.json** - Dependencies
3. **.env.example** - Environment variables template
4. **QUICKSTART.md** - Get running in 30 minutes ⭐ START HERE
5. **DEPLOYMENT.md** - Detailed setup & configuration guide
6. **README.md** - This file

---

## WHAT YOU GET

### Automated Deal Evaluation
- Claude AI evaluates every deal
- Applies your kill rubrics instantly
- Calculates metrics (cap rate, spread, cashflow)
- Determines deal quality score (0-100)
- Estimates fee potential

### Smart Notifications
- **SMS Alert** → Every qualified deal
- **Email Alert** → Summary with full analysis
- **Daily Digest** → Top 10 deals ranked by fee potential

### Database Storage
- Stores all deals (qualified and rejected)
- Never lose a deal again
- Search by market, date, quality, fee potential
- Historical tracking for analysis

### Integration Ready
- Accepts deals from Zapier webhooks
- Integrates with Google Forms
- Connects to email forwarding
- Works with Slack
- Ready for future API integrations

---

## YOUR KILL RUBRICS (Built-in)

### WMD ($10M-$150M Multifamily)
- **Price:** $10M - $150M
- **Units:** 32+
- **NOI:** >$900K
- **Occupancy:** >80%
- **Cap Rate:** 5-7% = SMS alert
- **Class:** A or B

### Ryan (St. Louis BRRR)
- **Units:** 2-4
- **ARV Spread:** >$20K
- **All qualified deals:** Get SMS alert

### David Ross (NC Co-Living)
- **Units:** 1-5
- **Price:** $100K-$550K
- **All qualified deals:** Get SMS alert

### Breakaway Properties (RV Parks)
- **Pads:** 20+
- **Price:** <$2M
- **Cashflow:** >$12K/month
- **All qualified deals:** Get SMS alert

---

## QUICK SETUP (30 minutes)

### 1. Get API Keys
- Anthropic (free): https://console.anthropic.com/
- Gmail (free): https://myaccount.google.com/security
- Twilio (free tier): https://www.twilio.com/console/

### 2. Set Environment
- Copy `.env.example` → `.env`
- Fill in your API keys
- Fill in your contact info

### 3. Deploy Server
- Go to https://render.com (free)
- Create new Web Service
- Connect this folder
- Deploy!

### 4. Connect Deal Sources
- Set up Zapier zaps to send deals to your server
- Connect CreXi, LoopNet, MLS, forms, etc.

### 5. Test
```bash
curl -X POST https://your-server/api/deal \
  -H "Content-Type: application/json" \
  -d '{"address":"123 Main","price":15000000,"business_type":"wmd","units":50,"noi":1200000,"cap_rate":6.2}'
```

---

## HOW IT WORKS

```
Deal Source (Zapier, Form, Email)
         ↓
    POST to /api/deal
         ↓
Claude AI Evaluation
  - Check kill rubric
  - Calculate metrics
  - Quality score
         ↓
    Store in DB
         ↓
   Send Notifications
  - SMS Alert
  - Email Alert
         ↓
   You Review & Act
```

---

## API ENDPOINTS

### Send a Deal
```
POST /api/deal
Body: {
  "address": "123 Main St",
  "property_type": "multifamily",
  "price": 15000000,
  "market": "Texas",
  "business_type": "wmd",
  "units": 45,
  "noi": 1200000,
  "occupancy": 85,
  "cap_rate": 6.5
}
```

### Get All Deals
```
GET /api/deals
```

### Get Deals by Market
```
GET /api/deals/wmd
GET /api/deals/ryan_stlouis
GET /api/deals/david_ross
GET /api/deals/bp_rvpark
```

---

## NOTIFICATIONS

### SMS Alert
Sent immediately when deal is found:
```
✅ wmd: 456 Oak Ave - Quality: 85/100 - Fee: $450,000
```

### Email Alert
Detailed analysis sent with:
- Deal address & price
- Market & business type
- Quality score
- Fee potential
- Full evaluation JSON

### Daily Digest
Email at 8am with:
- All deals found yesterday
- Ranked by fee potential
- Quality scores
- Summaries

---

## DEPLOYMENT OPTIONS

### Render.com (Recommended - Easiest)
- Free tier works perfectly
- Auto-deploys from GitHub
- 99% uptime
- No configuration needed
- URL: `https://landon-deal-va.onrender.com`

### Railway.app
- Also free
- Similar to Render
- Simple setup

### Local Computer (Testing)
```bash
npm install
node index.js
```

---

## COST BREAKDOWN

| Service | Cost | Purpose |
|---------|------|---------|
| Render | FREE | Server hosting |
| Anthropic | Pay-per-use ($0.03 per deal eval) | Deal evaluation |
| Gmail | FREE | Email notifications |
| Twilio | FREE tier ($15 credit) | SMS alerts |
| **Total** | **~$0.03 per deal** | Full automation |

---

## FUTURE ENHANCEMENTS

- [ ] Auto-send deals to partners (Ryan, David, WMD contacts)
- [ ] Auto-populate spreadsheets
- [ ] Advanced multi-criteria filtering
- [ ] Deal analytics dashboard
- [ ] Market trend analysis
- [ ] Competitor pricing alerts
- [ ] AI-powered deal negotiation suggestions

---

## TROUBLESHOOTING

**No SMS?**
- Check Twilio credits
- Verify phone in .env
- Check server logs

**No Email?**
- Use app password (not regular password)
- Check spam folder
- Verify Gmail settings

**Deals not processing?**
- Verify webhook URL is correct
- Test with curl command
- Check server logs in Render/Railway

**Need to change criteria?**
- Edit `killRubrics` in index.js
- Redeploy

---

## NEXT STEPS

1. **Read:** QUICKSTART.md (30 min setup)
2. **Deploy:** Follow DEPLOYMENT.md steps
3. **Test:** Send test deal via curl
4. **Connect:** Set up Zapier zaps
5. **Monitor:** Check SMS/email as deals come in
6. **Act:** Follow up on exceptional deals

---

**Your VA is live. Deals are coming. 🚀**

